﻿
namespace GrpcServer
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.chkServer = new System.Windows.Forms.CheckBox();
            this.cmdSelFile = new System.Windows.Forms.Button();
            this.txtUploadFile = new System.Windows.Forms.TextBox();
            this.cmdUpload = new System.Windows.Forms.Button();
            this.cmdCancelUpload = new System.Windows.Forms.Button();
            this.cmdDownload = new System.Windows.Forms.Button();
            this.cmdCancelDownload = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // chkServer
            // 
            this.chkServer.AutoSize = true;
            this.chkServer.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chkServer.Location = new System.Drawing.Point(28, 24);
            this.chkServer.Name = "chkServer";
            this.chkServer.Size = new System.Drawing.Size(114, 23);
            this.chkServer.TabIndex = 0;
            this.chkServer.Text = "Start Server";
            this.chkServer.UseVisualStyleBackColor = true;
            this.chkServer.CheckedChanged += new System.EventHandler(this.chkServer_CheckedChanged);
            // 
            // cmdSelFile
            // 
            this.cmdSelFile.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmdSelFile.Location = new System.Drawing.Point(28, 67);
            this.cmdSelFile.Name = "cmdSelFile";
            this.cmdSelFile.Size = new System.Drawing.Size(114, 38);
            this.cmdSelFile.TabIndex = 1;
            this.cmdSelFile.Text = "Select File";
            this.cmdSelFile.UseVisualStyleBackColor = true;
            this.cmdSelFile.Click += new System.EventHandler(this.cmdSelFile_Click);
            // 
            // txtUploadFile
            // 
            this.txtUploadFile.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtUploadFile.Location = new System.Drawing.Point(148, 74);
            this.txtUploadFile.Name = "txtUploadFile";
            this.txtUploadFile.Size = new System.Drawing.Size(492, 30);
            this.txtUploadFile.TabIndex = 2;
            // 
            // cmdUpload
            // 
            this.cmdUpload.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmdUpload.Location = new System.Drawing.Point(28, 127);
            this.cmdUpload.Name = "cmdUpload";
            this.cmdUpload.Size = new System.Drawing.Size(114, 38);
            this.cmdUpload.TabIndex = 3;
            this.cmdUpload.Text = "Upload";
            this.cmdUpload.UseVisualStyleBackColor = true;
            this.cmdUpload.Click += new System.EventHandler(this.cmdUpload_Click);
            // 
            // cmdCancelUpload
            // 
            this.cmdCancelUpload.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmdCancelUpload.Location = new System.Drawing.Point(206, 127);
            this.cmdCancelUpload.Name = "cmdCancelUpload";
            this.cmdCancelUpload.Size = new System.Drawing.Size(169, 38);
            this.cmdCancelUpload.TabIndex = 3;
            this.cmdCancelUpload.Text = "Cancel Upload";
            this.cmdCancelUpload.UseVisualStyleBackColor = true;
            this.cmdCancelUpload.Click += new System.EventHandler(this.cmdCancelUpload_Click);
            // 
            // cmdDownload
            // 
            this.cmdDownload.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmdDownload.Location = new System.Drawing.Point(28, 190);
            this.cmdDownload.Name = "cmdDownload";
            this.cmdDownload.Size = new System.Drawing.Size(114, 38);
            this.cmdDownload.TabIndex = 4;
            this.cmdDownload.Text = "Download";
            this.cmdDownload.UseVisualStyleBackColor = true;
            this.cmdDownload.Click += new System.EventHandler(this.cmdDownload_Click);
            // 
            // cmdCancelDownload
            // 
            this.cmdCancelDownload.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmdCancelDownload.Location = new System.Drawing.Point(206, 190);
            this.cmdCancelDownload.Name = "cmdCancelDownload";
            this.cmdCancelDownload.Size = new System.Drawing.Size(169, 38);
            this.cmdCancelDownload.TabIndex = 4;
            this.cmdCancelDownload.Text = "Cancel Download";
            this.cmdCancelDownload.UseVisualStyleBackColor = true;
            this.cmdCancelDownload.Click += new System.EventHandler(this.cmdCancelDownload_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblMessage.Location = new System.Drawing.Point(159, 28);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(72, 19);
            this.lblMessage.TabIndex = 5;
            this.lblMessage.Text = "Message";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(652, 254);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.cmdCancelDownload);
            this.Controls.Add(this.cmdDownload);
            this.Controls.Add(this.cmdCancelUpload);
            this.Controls.Add(this.cmdUpload);
            this.Controls.Add(this.txtUploadFile);
            this.Controls.Add(this.cmdSelFile);
            this.Controls.Add(this.chkServer);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chkServer;
        private System.Windows.Forms.Button cmdSelFile;
        private System.Windows.Forms.TextBox txtUploadFile;
        private System.Windows.Forms.Button cmdUpload;
        private System.Windows.Forms.Button cmdCancelUpload;
        private System.Windows.Forms.Button cmdDownload;
        private System.Windows.Forms.Button cmdCancelDownload;
        private System.Windows.Forms.Label lblMessage;
    }
}

