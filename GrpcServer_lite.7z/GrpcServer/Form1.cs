﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Grpc.Core;
using NLog;
using System.Threading;
using System.Windows;
using System.Windows.Input;



namespace GrpcServer
{


    public partial class Form1 : Form
    {
        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();
        Server server;

       

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private string GetFilePath()
        {
            // Create OpenFileDialog 
            //Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            OpenFileDialog dlg = new OpenFileDialog();
            // Set filter for file extension and default file extension 
            dlg.Title = "選擇檔案";
            dlg.Filter = "所有檔案(*.*)|*.*";
            dlg.FileName = "選擇資料夾.";
            dlg.FilterIndex = 1;
            dlg.ValidateNames = false;
            dlg.CheckFileExists = false;
            dlg.CheckPathExists = true;
            dlg.Multiselect = false;//允許同時選擇多個檔案 

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                return dlg.FileName;
            }
            else
                return string.Empty;
        }

        private void chkServer_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkServer.Checked)
                {
                    //提供服務
                    server = new Server()
                    {
                        Services = { GrpcService.FileTransfer.BindService(new FileImpl()) },
                        Ports = { new ServerPort("127.0.0.1", 50000, ServerCredentials.Insecure) }
                    };
                    //服務開始
                    server.Start();
                }
                else
                {
                    //結束服務
                    server.ShutdownAsync();
                }
            }
            catch (Exception ex)
            {
                logger.Error("[chkServer] Err[" + ex.Message + "] Stack[" + ex.StackTrace + "]");
                throw;
            }

        }

        private void cmdSelFile_Click(object sender, EventArgs e)
        {
            txtUploadFile.Text = GetFilePath();
        }
        CancellationTokenSource uploadTokenSource;
        private async void cmdUpload_Click(object sender, EventArgs e)
        {
            lblMessage.Text = string.Empty;

            uploadTokenSource = new CancellationTokenSource();
            List<string> fileNames = new List<string>();
            fileNames.Add(txtUploadFile.Text);
            var result = await ServerNet.FileTransfer.FileUpload(fileNames, "123", uploadTokenSource.Token);

            lblMessage.Text = result.Message;

            uploadTokenSource = null;
        }

        private void cmdCancelUpload_Click(object sender, EventArgs e)
        {
            uploadTokenSource?.Cancel();
        }
        CancellationTokenSource downloadTokenSource;
        private async void cmdDownload_Click(object sender, EventArgs e)
        {
            lblMessage.Text = string.Empty;
            downloadTokenSource = new CancellationTokenSource();
            List<string> fileNames = new List<string>();
            fileNames.Add(System.IO.Path.GetFileName(txtUploadFile.Text));
            var result = await ServerNet.FileTransfer.FileDownload(fileNames, "123", Environment.CurrentDirectory + @"\DownFiles", downloadTokenSource.Token);

            lblMessage.Text = result.Message;

            downloadTokenSource = null;
        }

        private void cmdCancelDownload_Click(object sender, EventArgs e)
        {
            downloadTokenSource?.Cancel();
        }
    }




}
